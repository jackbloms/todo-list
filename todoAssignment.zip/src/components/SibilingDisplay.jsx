//rafce
import React from 'react'

const SibilingDisplay = (props) => {
    
    const handleUpdate=(e, idx)=>{
        const arrCopy = [...props.todoList]
        arrCopy[idx].isComplete = e.target.checked
        props.onListUpdate(arrCopy)
    }

    const handleDelete=(arrIdx)=>{
        const filteredList = props.toDo.filter((element, i)=>{
            return i !== arrIdx
        })
        props.onListUpdate(filteredList)
    }
    
    return (
        <fieldset>
            <legend>SiblingDisplay.jsx</legend>
            {
                props.todoList.map((eachTodo, i)=>{
                    return(
                        <pre key={i}>
                            {eachTodo.toDo}
                            <input type="checkbox" checked={eachTodo.isComplete}
                            onChange={(e)=>handleUpdate(i)}/>
                            <button onClick={(e)=>handleDelete(e, i)}>Delete</button>
                        </pre>
                    )
                })
            }
        </fieldset>
    )
}

export default SibilingDisplay