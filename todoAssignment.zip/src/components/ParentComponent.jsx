import React, {useState} from 'react'
import SibilingDisplay from './SibilingDisplay'
import SiblingForm from './SiblingForm'

const ParentComponent = () => {
    const [todoList, setTodoList] = useState([])

    const receiveNewTodo =(newTodo)=>{
        setTodoList([...todoList, newTodo])
    }

    const updateList=(updatedList)=>{
        setTodoList(updatedList)
    }


    return (
        <fieldset>
            <legend>ParentComponent.jsx</legend>
            <SiblingForm onNewTodo={receiveNewTodo}/>
            <SibilingDisplay todoList={todoList} onListUpdate={updateList}/>
        </fieldset>
    )
}

export default ParentComponent